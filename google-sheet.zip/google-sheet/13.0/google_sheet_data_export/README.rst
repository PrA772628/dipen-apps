


===============================
Google Sheet Export API
===============================

The module adds the possibility to Export data and create fields from odoo in Google Spreadsheet.

Major Issues
============

* When We Export Any Data From Odoo To Google Sheet And After That We import Same file Some Fields Data Are not Import 
  And Throw Error.
* The Date And Datetime Fields Data Are not Proper Import And Export.
* Many2one Fields Data not Import Proper When We import Sheet IF Any data Has no record In Many2one Field.

Major Fixed Issues
==================

* Fix And Solved Date And Datetime Field Import and Export Code.
* Fix And Solved Many2one Field Import and Export Code.
* On The OtherHand We Fix Some Other Problems.
* Remove Timestamp From date field and Fix it.